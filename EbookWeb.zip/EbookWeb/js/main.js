/* ============================================================
   E-BOOK PUBLISHERS CO. — MAIN JAVASCRIPT
   ============================================================ */

/* ---- Preloader ---- */
(function() {
    const fill = document.getElementById('preBarFill');
    let prog = 0;
    const iv = setInterval(() => {
        prog += Math.random() * 18;
        if (prog >= 100) { prog = 100; clearInterval(iv); }
        fill.style.width = prog + '%';
        if (prog === 100) {
            setTimeout(() => {
                document.getElementById('preloader').classList.add('hide');
                document.body.style.overflow = '';
                triggerHeroReveal();
            }, 300);
        }
    }, 120);
    document.body.style.overflow = 'hidden';
})();

function triggerHeroReveal() {
    document.querySelectorAll('.reveal-up').forEach((el, i) => {
        setTimeout(() => el.classList.add('vis'), i * 120);
    });
    document.querySelectorAll('.reveal-right').forEach((el, i) => {
        setTimeout(() => el.classList.add('vis'), 300 + i * 150);
    });
}

/* ---- Custom Cursor ---- */
(function() {
    const cur = document.getElementById('cursor');
    const trail = document.getElementById('cursorTrail');
    if (!cur || !trail) return;

    let mx = 0, my = 0, tx = 0, ty = 0;

    document.addEventListener('mousemove', e => {
        mx = e.clientX; my = e.clientY;
        cur.style.left = mx + 'px';
        cur.style.top = my + 'px';
    });

    function animTrail() {
        tx += (mx - tx) * 0.12;
        ty += (my - ty) * 0.12;
        trail.style.left = tx + 'px';
        trail.style.top = ty + 'px';
        requestAnimationFrame(animTrail);
    }
    animTrail();

    document.querySelectorAll('a, button, .svc-card, .book-tile, .tc-btn, .faq-q').forEach(el => {
        el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
        el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
    });
})();

/* ---- Scroll Progress ---- */
window.addEventListener('scroll', () => {
    const el = document.getElementById('scrollProgress');
    const h = document.documentElement;
    const pct = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
    el.style.width = pct + '%';
}, { passive: true });

/* ---- Navbar ---- */
(function() {
    const nav = document.getElementById('navbar');
    const ham = document.getElementById('hamburger');
    const links = document.getElementById('navLinks');
    const sections = document.querySelectorAll('section[id]');

    window.addEventListener('scroll', () => {
        nav.classList.toggle('scrolled', window.scrollY > 50);

        // Active link highlighting
        let cur = '';
        sections.forEach(s => {
            if (window.scrollY >= s.offsetTop - 100) cur = s.id;
        });
        document.querySelectorAll('.nav-link').forEach(a => {
            a.classList.toggle('active', a.getAttribute('href') === '#' + cur);
        });
    }, { passive: true });

    ham.addEventListener('click', () => {
        ham.classList.toggle('open');
        links.classList.toggle('open');
    });

    document.querySelectorAll('.nav-link').forEach(a => {
        a.addEventListener('click', () => {
            ham.classList.remove('open');
            links.classList.remove('open');
        });
    });
})();

/* ---- Canvas Particles ---- */
(function() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let particles = [];
    let W, H;

    function resize() {
        W = canvas.width = canvas.offsetWidth;
        H = canvas.height = canvas.offsetHeight;
    }
    resize();
    window.addEventListener('resize', resize, { passive: true });

    class Particle {
        constructor() { this.reset(); }
        reset() {
            this.x = Math.random() * W;
            this.y = Math.random() * H;
            this.r = Math.random() * 1.5 + 0.3;
            this.vx = (Math.random() - 0.5) * 0.3;
            this.vy = (Math.random() - 0.5) * 0.3;
            this.alpha = Math.random() * 0.5 + 0.1;
            this.color = Math.random() > 0.6 ? '#8B5CF6' : Math.random() > 0.5 ? '#0EA5E9' : '#A78BFA';
        }
        update() {
            this.x += this.vx; this.y += this.vy;
            if (this.x < 0 || this.x > W || this.y < 0 || this.y > H) this.reset();
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.globalAlpha = this.alpha;
            ctx.fill();
            ctx.globalAlpha = 1;
        }
    }

    for (let i = 0; i < 120; i++) particles.push(new Particle());

    // Connect nearby particles
    function drawConnections() {
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < 80) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = '#8B5CF6';
                    ctx.globalAlpha = (1 - d / 80) * 0.15;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                    ctx.globalAlpha = 1;
                }
            }
        }
    }

    function animate() {
        ctx.clearRect(0, 0, W, H);
        particles.forEach(p => { p.update(); p.draw(); });
        drawConnections();
        requestAnimationFrame(animate);
    }
    animate();
})();

/* ---- Typewriter ---- */
(function() {
    const el = document.getElementById('typed');
    if (!el) return;
    const words = ['Published', 'Heard', 'A Bestseller', 'Your Legacy', 'Remarkable'];
    let wi = 0, ci = 0, deleting = false;

    function type() {
        const word = words[wi];
        if (!deleting) {
            el.textContent = word.slice(0, ++ci);
            if (ci === word.length) { deleting = true; setTimeout(type, 2200); return; }
        } else {
            el.textContent = word.slice(0, --ci);
            if (ci === 0) { deleting = false; wi = (wi + 1) % words.length; }
        }
        setTimeout(type, deleting ? 60 : 100);
    }
    setTimeout(type, 1500);
})();

/* ---- Scroll Reveal (AOS) ---- */
(function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('aos-in');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('[data-aos]').forEach(el => observer.observe(el));

    // Process line fill trigger
    const pobs = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) {
                setTimeout(() => {
                    document.getElementById('plFill').style.width = '100%';
                }, 300);
                pobs.unobserve(e.target);
            }
        });
    }, { threshold: 0.3 });
    const pw = document.querySelector('.process-wrap');
    if (pw) pobs.observe(pw);
})();

/* ---- Counter Animation ---- */
(function() {
    const counters = document.querySelectorAll('.stat-num');
    if (!counters.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseInt(el.dataset.target);
            const duration = 1800;
            const step = target / (duration / 16);
            let current = 0;
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    el.textContent = target.toLocaleString();
                    clearInterval(timer);
                } else {
                    el.textContent = Math.floor(current).toLocaleString();
                }
            }, 16);
            observer.unobserve(el);
        });
    }, { threshold: 0.5 });

    counters.forEach(c => observer.observe(c));
})();

/* ---- 3D Tilt Effect ---- */
(function() {
    document.querySelectorAll('[data-tilt]').forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            const dx = (e.clientX - cx) / (rect.width / 2);
            const dy = (e.clientY - cy) / (rect.height / 2);
            card.style.transform = `perspective(800px) rotateX(${-dy * 6}deg) rotateY(${dx * 6}deg) translateY(-6px)`;
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
        });
    });
})();

/* ---- Book 3D Mouse Parallax ---- */
(function() {
    const book = document.getElementById('book3d');
    if (!book) return;
    document.addEventListener('mousemove', e => {
        const cx = window.innerWidth / 2;
        const cy = window.innerHeight / 2;
        const dx = (e.clientX - cx) / cx;
        const dy = (e.clientY - cy) / cy;
        book.style.transform = `rotateY(${-25 + dx * 8}deg) rotateX(${8 - dy * 5}deg)`;
    }, { passive: true });
})();

/* ---- Testimonials Slider ---- */
(function() {
    const track = document.getElementById('testiTrack');
    const dotsWrap = document.getElementById('tcDots');
    const prev = document.getElementById('tPrev');
    const next = document.getElementById('tNext');
    if (!track) return;

    const cards = track.querySelectorAll('.testi-card');
    let cur = 0;
    let auto;

    // Create dots
    cards.forEach((_, i) => {
        const d = document.createElement('div');
        d.className = 'tc-dot' + (i === 0 ? ' active' : '');
        d.addEventListener('click', () => goTo(i));
        dotsWrap.appendChild(d);
    });

    function goTo(n) {
        cards[cur].style.opacity = '';
        cur = (n + cards.length) % cards.length;
        track.style.transform = `translateX(-${cur * 100}%)`;
        dotsWrap.querySelectorAll('.tc-dot').forEach((d, i) => d.classList.toggle('active', i === cur));
        resetAuto();
    }

    function resetAuto() {
        clearInterval(auto);
        auto = setInterval(() => goTo(cur + 1), 5000);
    }

    prev.addEventListener('click', () => goTo(cur - 1));
    next.addEventListener('click', () => goTo(cur + 1));

    // Touch support
    let touchX = 0;
    track.addEventListener('touchstart', e => { touchX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', e => {
        const diff = touchX - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) goTo(cur + (diff > 0 ? 1 : -1));
    }, { passive: true });

    resetAuto();
})();

/* ---- Pricing Toggle ---- */
(function() {
    const toggle = document.getElementById('priceToggle');
    if (!toggle) return;
    toggle.addEventListener('change', () => {
        const monthly = toggle.checked;
        document.querySelectorAll('.pc-num').forEach(el => {
            const val = monthly ? el.dataset.mo : el.dataset.ot;
            el.style.transform = 'scale(0.8)';
            el.style.opacity = '0';
            setTimeout(() => {
                el.textContent = parseInt(val).toLocaleString();
                el.style.transform = '';
                el.style.opacity = '';
                el.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
            }, 150);
        });
    });
})();

/* ---- FAQ Accordion ---- */
(function() {
    document.querySelectorAll('.faq-item').forEach(item => {
        const btn = item.querySelector('.faq-q');
        const ans = item.querySelector('.faq-a');
        btn.addEventListener('click', () => {
            const open = item.classList.contains('open');
            // Close all
            document.querySelectorAll('.faq-item.open').forEach(other => {
                other.classList.remove('open');
                other.querySelector('.faq-a').style.maxHeight = '';
            });
            if (!open) {
                item.classList.add('open');
                ans.style.maxHeight = ans.scrollHeight + 'px';
            }
        });
    });
})();

/* ---- Form Validation ---- */
(function() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const submitBtn = document.getElementById('submitBtn');
    const btnText = submitBtn.querySelector('.btn-t');
    const btnLoad = submitBtn.querySelector('.btn-l');

    form.addEventListener('submit', e => {
        e.preventDefault();
        let valid = true;

        // Clear errors
        form.querySelectorAll('.fe').forEach(el => el.textContent = '');
        form.querySelectorAll('input, select, textarea').forEach(el => el.classList.remove('error'));

        // Validate
        const name = form.querySelector('[name="name"]');
        const email = form.querySelector('[name="email"]');
        const service = form.querySelector('[name="service"]');
        const message = form.querySelector('[name="message"]');

        if (!name.value.trim() || name.value.trim().length < 2) {
            setError(name, 'Please enter your full name');
            valid = false;
        }
        if (!isValidEmail(email.value)) {
            setError(email, 'Please enter a valid email address');
            valid = false;
        }
        if (!service.value) {
            setError(service, 'Please select a service');
            valid = false;
        }
        if (!message.value.trim() || message.value.trim().length < 20) {
            setError(message, 'Please tell us more about your project (min 20 chars)');
            valid = false;
        }

        if (!valid) return;

        // Submit animation
        btnText.style.display = 'none';
        btnLoad.style.display = 'flex';
        submitBtn.disabled = true;

        // Simulate submit
        setTimeout(() => {
            btnText.style.display = '';
            btnLoad.style.display = 'none';
            submitBtn.disabled = false;
            form.reset();
            showToast('🎉 Your quote request has been sent! We\'ll contact you within 24 hours.');
        }, 2000);
    });

    function setError(el, msg) {
        el.classList.add('error');
        const err = el.parentElement.querySelector('.fe');
        if (err) err.textContent = msg;
    }

    function isValidEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
})();

/* ---- Newsletter Form ---- */
document.getElementById('nlForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const input = e.target.querySelector('input');
    if (input.value) {
        input.value = '';
        showToast('✅ You\'re subscribed! Check your inbox for a free writing guide.');
    }
});

/* ---- Toast ---- */
function showToast(msg) {
    const toast = document.getElementById('toast');
    const msgEl = document.getElementById('toastMsg');
    msgEl.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 4500);
}

/* ---- Back to Top ---- */
(function() {
    const btn = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
        btn.classList.toggle('show', window.scrollY > 400);
    }, { passive: true });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
})();

/* ---- Smooth Scroll (fallback for older browsers) ---- */
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const id = a.getAttribute('href');
        if (id === '#') return;
        const target = document.querySelector(id);
        if (target) {
            e.preventDefault();
            const top = target.getBoundingClientRect().top + window.scrollY - 80;
            window.scrollTo({ top, behavior: 'smooth' });
        }
    });
});

/* ---- Stats section AOS delay stagger ---- */
document.querySelectorAll('#stats .stat-item').forEach((el, i) => {
    el.style.transitionDelay = i * 0.1 + 's';
});

/* ---- Service card AOS stagger ---- */
document.querySelectorAll('.svc-card').forEach((el, i) => {
    el.style.transitionDelay = (i % 4) * 0.08 + 's';
});
